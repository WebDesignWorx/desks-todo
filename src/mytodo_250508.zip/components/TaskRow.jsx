import React, { useState, useRef, useEffect } from 'react';
import MarkdownIt from 'markdown-it';

const md = new MarkdownIt({ html: false, linkify: true });

export default function TaskRow({
  task,
  depth,
  onToggleDone,
  onTextChange,
  onAddBelow,
  onAddChild,
  onArchive,
  dragAttributes,
  dragListeners,
}) {
  const [editing, setEditing] = useState(!task.name);
  const [value, setValue] = useState(task.name || '');
  const inputRef = useRef();

  /* focus input whenever we enter edit-mode */
  useEffect(() => {
    if (editing) inputRef.current?.focus();
  }, [editing]);

  /* re-sync local value if external task.name changes (reload etc.) */
  useEffect(() => {
    setValue(task.name || '');
  }, [task.name]);

  /* commit current text */
  const commit = () => {
    const txt = value.trim();
    setEditing(false);
    if (txt !== task.name) onTextChange(task.id, txt);
  };

  return (
    <div
      className="flex items-center group mb-1 bg-white hover:bg-gray-50 rounded px-2 py-1"
      style={{ paddingLeft: depth * 20 }}
    >
      {/* drag handle */}
      <span
        {...dragAttributes}
        {...dragListeners}
        className="mr-2 cursor-grab opacity-0 group-hover:opacity-100"
      >
        <svg viewBox="0 0 20 20" width="16">
          <path d="M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z" />
        </svg>
      </span>

      {/* checkbox */}
      <input
        type="checkbox"
        checked={task.done}
        onChange={() => onToggleDone(task.id)}
        className="mr-2"
      />

      {/* inline editor / renderer */}
      {editing ? (
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              commit();
              onAddBelow(task.id);
            } else if (e.key === 'Tab') {
              e.preventDefault();
              commit();
              onAddChild(task.id);
            }
          }}
          className="flex-1 bg-transparent outline-none border-b border-indigo-300"
        />
      ) : (
        <div
          onDoubleClick={() => setEditing(true)}
          className={`flex-1 select-none ${
            task.done ? 'text-gray-400 line-through' : ''
          }`}
          dangerouslySetInnerHTML={{
            __html: task.name
              ? md.renderInline(task.name)
              : '<em class="text-gray-400">[empty]</em>',
          }}
        />
      )}

      {/* archive */}
      <button
        onClick={() => onArchive(task.id)}
        className="ml-2 text-red-500 opacity-0 group-hover:opacity-100"
        title="Archive"
      >
        ×
      </button>
    </div>
  );
}
