// src/components/TaskTree.jsx
import React, { useMemo, useState, useCallback } from 'react';
import {
  DndContext,
  PointerSensor,
  useSensor,
  useSensors,
  closestCenter,
  DragOverlay,
} from '@dnd-kit/core';
import {
  SortableContext,
  useSortable,
  arrayMove,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import TaskRow from './TaskRow';

////////////////////////////////////////////////////////////////////////////////
// helpers → convert flat list  ↔  tree array
////////////////////////////////////////////////////////////////////////////////
const buildTree = (flat) => {
  const byId = Object.fromEntries(flat.map((t) => [t.id, { ...t, children: [] }]));
  const roots = [];
  for (const t of Object.values(byId)) {
    if (t.parent_id == null) roots.push(t);
    else byId[t.parent_id]?.children.push(t);
  }
  // sort children arrays by .position
  const sort = (arr) => arr.sort((a, b) => a.position - b.position).forEach((c) => sort(c.children));
  sort(roots);
  return roots;
};

const flattenTree = (nodes, depth = 0, out = []) => {
  nodes.forEach((n) => {
    out.push({ ...n, depth });
    flattenTree(n.children, depth + 1, out);
  });
  return out;
};

////////////////////////////////////////////////////////////////////////////////
// single Task line wrapped with useSortable
////////////////////////////////////////////////////////////////////////////////
function SortableItem({ node, depth, collapsedIds, toggleCollapse, rowProps }) {
  const { setNodeRef, attributes, listeners, transform, transition, isDragging } =
    useSortable({ id: node.id });

  const style = {
    transform: CSS.Translate.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const caret =
    node.children.length > 0 ? (
      <button
        onClick={() => toggleCollapse(node.id)}
        className="mr-1 w-4 text-gray-500 focus:outline-none"
      >
        {collapsedIds.has(node.id) ? '▸' : '▾'}
      </button>
    ) : (
      <span className="mr-1 w-4" />
    );

  return (
    <li ref={setNodeRef} style={style}>
      {caret}
      <TaskRow
        task={node}
        depth={depth}
        dragAttributes={attributes}
        dragListeners={listeners}
        {...rowProps}
      />
    </li>
  );
}

////////////////////////////////////////////////////////////////////////////////
// Tree component
////////////////////////////////////////////////////////////////////////////////
export default function TaskTree({ tasks, setTasks, ...rowCallbacks }) {
  // collapse state
  const [collapsedIds, setCollapsed] = useState(
    () => new Set(JSON.parse(localStorage.getItem('collapsed') || '[]'))
  );
  const toggleCollapse = (id) => {
    const next = new Set(collapsedIds);
    next.has(id) ? next.delete(id) : next.add(id);
    setCollapsed(next);
    localStorage.setItem('collapsed', JSON.stringify([...next]));
  };

  // build tree & visible flat list
  const tree = useMemo(() => buildTree(tasks), [tasks]);
  const visibleFlat = useMemo(
    () =>
      flattenTree(tree).filter((n) => {
        // hide nodes whose parent is collapsed
        let p = n.parent_id;
        while (p) {
          if (collapsedIds.has(p)) return false;
          p = tasks.find((t) => t.id === p)?.parent_id;
        }
        return true;
      }),
    [tree, collapsedIds, tasks]
  );

  // dnd-kit sensors
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  // basic drag overlay
  const [activeId, setActiveId] = useState(null);

  ////////////////////////////////////////////////////////////////////////////
  // DnD handlers
  ////////////////////////////////////////////////////////////////////////////
  const handleDragEnd = ({ active, over }) => {
    setActiveId(null);
    if (!over || active.id === over.id) return;

    const activeIdx = visibleFlat.findIndex((n) => n.id === active.id);
    const overIdx = visibleFlat.findIndex((n) => n.id === over.id);
    if (activeIdx === -1 || overIdx === -1) return;

    const newFlat = arrayMove(visibleFlat, activeIdx, overIdx);

    // recompute parent & position from reordered flat list
    const updated = tasks.map((t) => ({ ...t })); // clone
    let lastAtDepth = [null]; // index by depth
    newFlat.forEach((node, idx) => {
      lastAtDepth[node.depth] = node.id;
      lastAtDepth.length = node.depth + 1; // truncate deeper levels

      const newParentId = node.depth === 0 ? null : lastAtDepth[node.depth - 1];
      const t = updated.find((x) => x.id === node.id);
      t.parent_id = newParentId;
      t.position = idx;
    });

    setTasks(updated);
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={({ active }) => setActiveId(active.id)}
      onDragEnd={handleDragEnd}
    >
      <SortableContext items={visibleFlat.map((n) => n.id)} strategy={rectSortingStrategy}>
        <ul className="select-none">
          {visibleFlat.map((node) => (
            <SortableItem
              key={node.id}
              node={node}
              depth={node.depth}
              collapsedIds={collapsedIds}
              toggleCollapse={toggleCollapse}
              rowProps={rowCallbacks}
            />
          ))}
        </ul>
      </SortableContext>

      <DragOverlay>
        {activeId && (
          <div className="px-2 py-1 bg-white rounded shadow-md border">
            {tasks.find((t) => t.id === activeId)?.name}
          </div>
        )}
      </DragOverlay>
    </DndContext>
  );
}
