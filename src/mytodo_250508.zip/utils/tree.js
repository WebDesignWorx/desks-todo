// build a nested tree out of your flat tasks[]
export function buildTree(tasks) {
  const byId = Object.fromEntries(tasks.map(t => [t.id, { ...t, children: [] }]));
  const roots = [];
  tasks.forEach(t => {
    if (t.parent_id && byId[t.parent_id]) {
      byId[t.parent_id].children.push(byId[t.id]);
    } else {
      roots.push(byId[t.id]);
    }
  });
  return roots;
}

// flatten tree → [{id, item, depth, parent, children}]
export function flattenTree(nodes, depth = 0, parent = null) {
  return nodes.reduce((acc, node) => {
    acc.push({ id: node.id, item: node, depth, parent, children: node.children });
    if (node.children?.length && !node.collapsed) {
      acc.push(...flattenTree(node.children, depth + 1, node.id));
    }
    return acc;
  }, []);
}

// walk & update one node by id (helper for toggle collapse/expand)
export function mapTree(nodes, id, fn) {
  return nodes.map(n =>
    n.id === id ? fn(n) : { ...n, children: mapTree(n.children || [], id, fn) }
  );
}

