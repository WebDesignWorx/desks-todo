import { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import {
  getTasksByDeskId,
  saveTask,
  archiveTaskById,
  pruneEmptyTasks,
  deleteTaskById,
} from '../utils/idb.js';
import ArchiveList from './ArchiveList';
import TaskTree from '../components/TaskTree';
import { v4 as uuidv4 } from 'uuid';

export default function TaskPage() {
  const { deskId } = useParams();
  const [tasks, setTasksRaw] = useState([]);
  const addInputRef = useRef(null);

  // load tasks & prune empties on desk change
  useEffect(() => {
    (async () => {
      await pruneEmptyTasks(deskId);
      const t = await getTasksByDeskId(deskId);
      setTasksRaw(t);
    })();
    localStorage.setItem('lastDesk', deskId);
  }, [deskId]);

  // wrapper that updates state _and_ persists each change
  const update = (recipe) =>
    setTasksRaw((prev) => {
      const next = recipe(prev);
      next.forEach(saveTask);
      return next;
    });

  // call this to replace the array wholesale (e.g. reorder)
  const persist = (newArray) => update(() => newArray);

  // toggles done
  const toggleDone = (id) =>
    update((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    );

  // edit text
  const changeText = (id, txt) =>
    update((prev) => prev.map((t) => (t.id === id ? { ...t, name: txt } : t)));

  // soft-archive
  const archive = (id) =>
    update((prev) =>
      prev.map((t) => (t.id === id ? { ...t, archived: true } : t))
    );

  // restore from archive
  const restore = async (id) => {
    await archiveTaskById(id);
    const fresh = await getTasksByDeskId(deskId);
    setTasksRaw(fresh);
  };

  // permanent delete
  const deletePermanent = async (id) => {
    await deleteTaskById(id);
    const fresh = await getTasksByDeskId(deskId);
    setTasksRaw(fresh);
  };

  // add sibling below
  const onBelow = (id) =>
    update((prev) => {
      const sib = prev.find((t) => t.id === id);
      const blank = {
        id: uuidv4(),
        desk_id: sib.desk_id,
        parent_id: sib.parent_id,
        name: '',
        done: false,
        archived: false,
        position: sib.position + 0.5,
      };
      return [...prev, blank];
    });

  // add child
  const onChild = (parent) =>
    update((prev) =>
      prev.concat({
        id: uuidv4(),
        desk_id: deskId,
        name: '',
        parent_id: parent,
        done: false,
        archived: false,
        position: Date.now(),
      })
    );

  // add root
  const addRootTask = (text) =>
    persist(
      tasks.concat({
        id: uuidv4(),
        desk_id: deskId,
        name: text,
        parent_id: null,
        done: false,
        archived: false,
        position: Date.now(),
      })
    );

  const [showArc, setShowArc] = useState(false);

  return (
    <div className="flex flex-col h-full">
      {tasks.length === 0 && (
        <p className="text-gray-500 mb-4">No tasks yet — start by adding one.</p>
      )}

      {tasks.length > 0 && (
        <TaskTree
            tasks={tasks}
            setTasks={(next) => {
              setTasks(next);          // ← your local state
              next.forEach(saveTask);  // ← persist to IndexedDB
            }}
            onTextChange={changeText}
            onToggleDone={toggleDone}
            onAddBelow={onBelow}
            onAddChild={onChild}
            onArchive={archive}
        />

      )}

      <button
        className="text-blue-600 text-sm mt-2"
        onClick={() => setShowArc((v) => !v)}
      >
        {showArc
          ? '[ hide archive ]'
          : `[ show archive (${tasks.filter((t) => t.archived).length}) ]`}
      </button>

      {showArc && (
        <ArchiveList
          tasks={tasks.filter((t) => t.archived)}
          onRestore={restore}
          onDeletePermanent={deletePermanent}
        />
      )}

      <div className="mt-auto pt-4">
        <input
          ref={addInputRef}
          className="border rounded px-3 py-2 w-full"
          placeholder="Add task…"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && e.currentTarget.value.trim()) {
              const txt = e.currentTarget.value.trim();
              e.currentTarget.value = '';
              addRootTask(txt);
            }
          }}
        />
      </div>
    </div>
  );
}
