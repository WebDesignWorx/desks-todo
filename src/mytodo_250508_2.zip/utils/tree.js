/**
 * Tree utilities – plain JS version
 * ---------------------------------
 * A Node = { task: originalTask, children: Node[] }
 */

export const buildTree = (flat) => {
  const map = {};
  flat.forEach((t) => (map[t.id] = { task: t, children: [] }));

  const roots = [];
  flat.forEach((t) =>
    t.parent_id ? map[t.parent_id]?.children.push(map[t.id]) : roots.push(map[t.id]),
  );
  return roots;
};

export const flattenTree = (nodes, collapsed, keepTask = false, depth = 0) => {
  const src = Array.isArray(nodes) ? nodes : [nodes];
  const out = [];
  src.forEach((n) => {
    out.push(keepTask ? { ...n.task } : { task: n.task, depth });
    if (!collapsed.has(n.task.id) && n.children.length) {
      out.push(...flattenTree(n.children, collapsed, keepTask, depth + 1));
    }
  });
  return out;
};

/* ------------------------------------------------------------------ */
/* move a branch (dragId) so it sits just before dropId in same array  */

export const moveBranch = (tree, dragId, dropId) => {
  let dragNode = null;

  /* 1. remove from current place */
  const remove = (arr) => {
    const idx = arr.findIndex((n) => n.task.id === dragId);
    if (idx > -1) dragNode = arr.splice(idx, 1)[0];
    else arr.forEach((n) => remove(n.children));
  };
  remove(tree);
  if (!dragNode) return tree;

  /* 2. insert before dropId */
  const insert = (arr, parent) => {
    const idx = arr.findIndex((n) => n.task.id === dropId);
    if (idx > -1) {
      arr.splice(idx, 0, dragNode);
      dragNode.task.parent_id = parent ? parent.task.id : null;
    } else arr.forEach((n) => insert(n.children, n));
  };
  insert(tree, null);

  /* 3. renumber positions */
  renumber(tree, 0);
  return tree;
};

const renumber = (arr, pos) =>
  arr
    .sort((a, b) => a.task.position - b.task.position)
    .forEach((n, i) => {
      n.task.position = pos + i;
      renumber(n.children, 0);
    });
