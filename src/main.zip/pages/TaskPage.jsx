import { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';

import {
  getTasksByDeskId,
  saveTask,
  archiveTaskById,
  pruneEmptyTasks,
} from '../utils/idb.js';
import ArchiveList from './ArchiveList';
import TaskTree from '../components/TaskTree';
import { v4 as uuidv4 } from 'uuid';

export default function TaskPage() {
  const { deskId } = useParams();
  const [tasks, setTasks] = useState([]);      // now holds **all** tasks
  const [showArc, setShowArc] = useState(false);
  const addInputRef = useRef(null);

  useEffect(() => {
    (async () => {
      await pruneEmptyTasks(deskId);

      // ◀️ load **all** tasks, including archived
      const all = await getTasksByDeskId(deskId, true);
      setTasks(all);
    })();
    localStorage.setItem('lastDesk', deskId);
  }, [deskId]);

  // ▶️ master updater
  const update = (recipe) =>
    setTasks((prev) => {
      const next = recipe(prev);
      next.forEach(saveTask);
      return next;
    });

  // ✅ toggle-done
  const toggleDone = (id) =>
    update((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, done: !t.done } : t
      )
    );

  // ✏️ change text
  const changeText = (id, txt) =>
    update((prev) =>
      prev.map((t) => (t.id === id ? { ...t, name: txt } : t))
    );

  // 📦 archive
  const archive = (id) =>
    update((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, archived: true } : t
      )
    );

  // ➕ add below
  const onBelow = (id) =>
    update((prev) => {
      const sibling = prev.find((t) => t.id === id);
      const newTask = {
        id: uuidv4(),
        desk_id: sibling.desk_id,
        parent_id: sibling.parent_id,
        name: '',
        done: false,
        archived: false,
        position: sibling.position + 0.5,
      };
      return [...prev, newTask];
    });

  // ➕ add child
  const onChild = (parentId) =>
    update((prev) => [
      ...prev,
      {
        id: uuidv4(),
        desk_id: deskId,
        name: '',
        done: false,
        archived: false,
        parent_id: parentId,
        position: Date.now(),
      },
    ]);

  // ➕ add root
  const addRootTask = (text) => {
    const t = {
      id: uuidv4(),
      desk_id: deskId,
      name: text,
      parent_id: null,
      done: false,
      archived: false,
      position: Date.now(),
    };
    update((prev) => [...prev, t]);
  };

  // ▶️ persist wrapper for DnD & text edits from children
  const persist = (arr) => update(() => arr);

  // split into live vs archived for rendering
  const liveTasks = tasks.filter((t) => !t.archived);
  const archivedTasks = tasks.filter((t) => t.archived);

  return (
    <div className="flex flex-col h-full">
      {liveTasks.length === 0 && (
        <p className="text-gray-500 mb-4">
          No tasks yet — start by adding one.
        </p>
      )}

      {liveTasks.length > 0 && (
        <TaskTree
          tasks={liveTasks}
          setTasks={persist}
          onTextChange={changeText}
          onToggleDone={toggleDone}
          onAddBelow={onBelow}
          onAddChild={onChild}
          onArchive={archive}
        />
      )}

      <button
        className="text-blue-600 text-sm mt-2 self-start"
        onClick={() => setShowArc((v) => !v)}
      >
        {showArc
          ? '[ hide archive ]'
          : `[ show archive (${archivedTasks.length}) ]`}
      </button>

      {showArc && (
        <ArchiveList
          tasks={archivedTasks}
          refresh={async () => {
            const all = await getTasksByDeskId(deskId, true);
            setTasks(all);
          }}
        />
      )}

      <div className="mt-auto pt-4">
        <input
          ref={addInputRef}
          className="border rounded px-3 py-2 w-full"
          placeholder="Add task…"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && e.currentTarget.value.trim()) {
              const txt = e.currentTarget.value.trim();
              e.currentTarget.value = '';
              addRootTask(txt);
            }
          }}
        />
      </div>
    </div>
  );
}
