import { Link } from 'react-router-dom';
import logo from "../styles/logo.svg";

export default function Header() {
  return (
    <header className="h-16 flex items-center px-6 bg-slate-800 text-white shadow">
      <Link to="/" className="text-xl font-semibold hover:underline">[]</Link>
      <h1><img src={logo} alt="" width="64"/> Branched</h1>
      
    </header>
  );
}
