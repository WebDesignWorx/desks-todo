import { useEffect, useRef, useState } from 'react';
import MarkdownIt from 'markdown-it';

const md = new MarkdownIt({ html: false, linkify: true });

export default function TaskRow({
  task,
  depth,
  onToggleDone,
  onTextChange,
  onAddBelow,
  onAddChild,
  onArchive,
  dragAttributes,
  dragListeners,
  setDragRef,
  style,
  className = ''
}) {
  const [editing, setEditing] = useState(!task.name);
  const [value, setValue] = useState(task.name || '');
  const inputRef = useRef();

  /* auto-focus when editing starts */
  useEffect(() => {
    if (editing) inputRef.current?.focus();
  }, [editing]);

  /* re-sync if external name changes */
  useEffect(() => {
    setValue(task.name || '');
  }, [task.name]);

  const commit = () => {
    const trimmed = value.trim();
    setEditing(false);
    if (trimmed !== task.name) {
      onTextChange(task.id, trimmed);
    }
  };

  return (
    <li
      ref={setDragRef}
      style={{ paddingLeft: depth * 24, ...style }}
      className={`task-row flex items-center gap-2 mb-1 group ${className}`}
    >
      {/* checkbox */}
      <input
        type="checkbox"
        checked={task.done}
        onChange={() => onToggleDone(task.id)}
        className="h-4 w-4"
      />

      {/* drag handle */}
      <span
        {...dragAttributes}
        {...dragListeners}
        className="task-handle cursor-grab group-hover:cursor-grabbing opacity-0 group-hover:opacity-100"
      >
        ☰
      </span>

      {/* title or input */}
      {editing ? (
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={e => setValue(e.target.value)}
          onBlur={commit}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              commit();
              onAddBelow(task.id);
            } else if (e.key === 'Tab') {
              e.preventDefault();
              commit();
              onAddChild(task.id);
            }
          }}
          className="flex-1 bg-transparent outline-none border-b border-indigo-300"
        />
      ) : (
        <div
          onDoubleClick={() => setEditing(true)}
          className={`flex-1 select-none ${task.done ? 'task-checked-done' : ''}`}
          dangerouslySetInnerHTML={{
            __html: task.name
              ? md.renderInline(task.name)
              : `<em class="text-neutral-400">[empty]</em>`
          }}
        />
      )}

      {/* archive */}
      <button
        onClick={() => onArchive(task.id)}
        className="text-red-500 hover:text-red-700 opacity-0 group-hover:opacity-100"
        title="Archive"
      >
        ×
      </button>
    </li>
  );
}
