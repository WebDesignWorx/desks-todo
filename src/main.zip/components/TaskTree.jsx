import { useState, useCallback } from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';

import SortableWrapper from './SortableWrapper';
import TaskRow from './TaskRow';

export default function TaskTree({
  tasks,
  onTextChange,
  onToggleDone,
  onAddBelow,
  onAddChild,
  onArchive,
  setTasks, // expect: newArray => void
}) {
  const [activeId, setActiveId] = useState(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor)
  );

  const handleDragEnd = useCallback(
    ({ active, over }) => {
      setActiveId(null);
      if (over && active.id !== over.id) {
        // compute new order at this level
        const oldIndex = tasks.findIndex(t => t.id === active.id);
        const newIndex = tasks.findIndex(t => t.id === over.id);
        const next = [...tasks];
        next.splice(oldIndex, 1);
        next.splice(newIndex, 0, tasks[oldIndex]);
        setTasks(next);
      }
    },
    [tasks, setTasks]
  );

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={({ active }) => setActiveId(active.id)}
      onDragEnd={handleDragEnd}
      onDragCancel={() => setActiveId(null)}
    >
      <SortableContext
        items={tasks.map(t => t.id)}
        strategy={verticalListSortingStrategy}
      >
        {tasks.map(t => (
          <SortableWrapper
            key={t.id}
            task={t}
            depth={t.depth}
            onTextChange={onTextChange}
            onToggleDone={onToggleDone}
            onAddBelow={onAddBelow}
            onAddChild={onAddChild}
            onArchive={onArchive}
          />
        ))}
      </SortableContext>

      <DragOverlay>
        {activeId ? (
          <TaskRow
            task={tasks.find(t => t.id === activeId)}
            depth={0}
            onTextChange={onTextChange}
            onToggleDone={onToggleDone}
            onAddBelow={onAddBelow}
            onAddChild={onAddChild}
            onArchive={onArchive}
            dragAttributes={{}}
            dragListeners={{}}
            setDragRef={() => {}}
            className="drag-overlay"
          />
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
